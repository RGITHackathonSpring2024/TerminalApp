package ru.nosqd.rgit.terminalapp

enum class ListenMode {
    INFO,
    WITHDRAW
}