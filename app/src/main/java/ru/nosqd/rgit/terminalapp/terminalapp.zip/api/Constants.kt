package ru.nosqd.rgit.terminalapp.api

const val API_URL = "http://8.tcp.us-cal-1.ngrok.io:12283"
const val API_SECRET = "secretapikey"
const val INSTITUTION_ID = "662401ff1eb96bc202068b66"

